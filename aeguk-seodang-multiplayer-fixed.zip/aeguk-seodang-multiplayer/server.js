const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] }
});

const HTML_FILE = 'aeguk_seodang_integrated.html';
app.use(express.static(__dirname));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, HTML_FILE)));

const rooms = new Map();

function makeRoomCode() {
  let code;
  do { code = String(Math.floor(1000 + Math.random() * 9000)); }
  while (rooms.has(code));
  return code;
}

function publicPlayers(room) {
  return room.players.map(({ id, nickname, score, answered, isHost }) => ({ id, nickname, score, answered, isHost }));
}

io.on('connection', (socket) => {
  socket.on('create_room', (payload = {}) => {
    const nickname = String(payload.nickname || '방장 선비').trim().slice(0, 12) || '방장 선비';
    const questions = Array.isArray(payload.questions) ? payload.questions.slice(0, 30) : [];
    if (!questions.length || questions.some(q => !q || typeof q.text !== 'string' || !Array.isArray(q.options) || q.options.length < 2 || !Number.isInteger(q.answerIndex) || q.answerIndex < 0 || q.answerIndex >= q.options.length)) {
      socket.emit('room_error', { message: '퀴즈 문제를 준비하지 못했습니다. 다시 시도해 주세요.' });
      return;
    }
    const code = makeRoomCode();
    const room = {
      code, hostId: socket.id,
      players: [{ id: socket.id, nickname, score: 0, answered: false, isHost: true }],
      questions, currentIdx: 0, timer: null, nextTimer: null,
      started: false, roundActive: false
    };
    rooms.set(code, room);
    socket.join(code);
    socket.emit('room_created', { code, players: publicPlayers(room) });
  });

  socket.on('join_room', (payload = {}) => {
    const code = String(payload.code || '').trim();
    const room = rooms.get(code);
    if (!room) return socket.emit('room_error', { message: '존재하지 않는 초대 코드입니다.' });
    if (room.started) return socket.emit('room_error', { message: '이미 대결이 시작된 방입니다.' });
    if (room.players.length >= 4) return socket.emit('room_error', { message: '방 정원(4명)이 가득 찼습니다.' });
    const nickname = String(payload.nickname || '참가 선비').trim().slice(0, 12) || '참가 선비';
    room.players.push({ id: socket.id, nickname, score: 0, answered: false, isHost: false });
    socket.join(code);
    io.to(code).emit('room_updated', { code, players: publicPlayers(room) });
  });

  socket.on('start_room_game', (payload = {}) => {
    const code = String(payload.code || '').trim();
    const room = rooms.get(code);
    if (!room || room.hostId !== socket.id || room.started || room.players.length < 1) return;
    room.started = true;
    room.currentIdx = 0;
    room.players.forEach(p => { p.score = 0; p.answered = false; });
    io.to(code).emit('game_started', { total: room.questions.length });
    room.nextTimer = setTimeout(() => sendNextQuestion(code), 800);
  });

  socket.on('submit_answer', (payload = {}) => {
    const code = String(payload.code || '').trim();
    const room = rooms.get(code);
    if (!room || !room.started || !room.roundActive) return;
    const player = room.players.find(p => p.id === socket.id);
    if (!player || player.answered) return;
    const q = room.questions[room.currentIdx];
    if (!q) return;
    player.answered = true;
    const answerIndex = Number(payload.answerIndex);
    const leftSeconds = Math.max(0, Math.min(15, Number(payload.leftSeconds) || 0));
    if (answerIndex === q.answerIndex) player.score += 100 + leftSeconds * 20;
    io.to(code).emit('score_updated', { players: publicPlayers(room) });
    if (room.players.length && room.players.every(p => p.answered)) finishRound(code);
  });

  socket.on('disconnect', () => {
    for (const [code, room] of rooms.entries()) {
      const idx = room.players.findIndex(p => p.id === socket.id);
      if (idx === -1) continue;
      room.players.splice(idx, 1);
      if (!room.players.length) {
        clearTimeout(room.timer); clearTimeout(room.nextTimer); rooms.delete(code);
        break;
      }
      if (room.hostId === socket.id) {
        room.hostId = room.players[0].id;
        room.players.forEach(p => { p.isHost = p.id === room.hostId; });
      }
      io.to(code).emit('room_updated', { code, players: publicPlayers(room) });
      if (room.started && room.roundActive && room.players.every(p => p.answered)) finishRound(code);
      break;
    }
  });
});

function sendNextQuestion(code) {
  const room = rooms.get(code);
  if (!room) return;
  if (room.currentIdx >= room.questions.length) {
    const ranked = [...room.players].sort((a, b) => b.score - a.score);
    io.to(code).emit('game_over', { ranked: publicPlayers({ players: ranked }) });
    clearTimeout(room.timer); clearTimeout(room.nextTimer); rooms.delete(code);
    return;
  }
  room.players.forEach(p => { p.answered = false; });
  room.roundActive = true;
  const q = room.questions[room.currentIdx];
  io.to(code).emit('next_question', {
    index: room.currentIdx, total: room.questions.length,
    text: q.text, options: q.options, timeLimit: 15
  });
  clearTimeout(room.timer);
  room.timer = setTimeout(() => finishRound(code), 15500);
}

function finishRound(code) {
  const room = rooms.get(code);
  if (!room || !room.roundActive) return;
  room.roundActive = false;
  clearTimeout(room.timer);
  const q = room.questions[room.currentIdx];
  if (!q) return;
  io.to(code).emit('round_reveal', { answerIndex: q.answerIndex, players: publicPlayers(room) });
  room.currentIdx += 1;
  clearTimeout(room.nextTimer);
  room.nextTimer = setTimeout(() => sendNextQuestion(code), 1500);
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`AEGUK 실시간 서버 가동: http://localhost:${PORT}`));
