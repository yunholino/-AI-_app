# [PRD 인덱스] AI 기반 고전 국어 학습 애플리케이션 명세서 모음

고전 국어 AI 학습 애플리케이션의 제품 요구사항 정의서(PRD)를 영역별·기능별로 분리하여 체계적으로 구성한 문서 목록입니다.

---

## 📚 PRD 세부 문서 목록

| 번호 | 문서명 | 주요 내용 | 링크 |
|---|---|---|---|
| **00** | **프로젝트 개요 및 비전** | 프로젝트 배경, 핵심 가치, 타깃 페르소나, 개발 원칙 | [00_OVERVIEW.md](file:///c:/Users/user/Desktop/aeguk/docs/00_OVERVIEW.md) |
| **01** | **개인 맞춤형 초기 설정 (온보딩)** | 직업 및 학년, 학습 목표, 관심 분야 설정, 프로필 데이터 관리 | [01_ONBOARDING_USER_PROFILE.md](file:///c:/Users/user/Desktop/aeguk/docs/01_ONBOARDING_USER_PROFILE.md) |
| **02** | **AI 옛글 촬영 & 번역·해설** | 카메라 캡처/업로드, 고어 OCR, 현대어 번역 및 형태소/문법 해설 파이프라인 | [02_AI_SCAN_TRANSLATION.md](file:///c:/Users/user/Desktop/aeguk/docs/02_AI_SCAN_TRANSLATION.md) |
| **03** | **고전문학 & 어휘 학습장** | 주요 고전문학 라이브러리 대역 뷰어, 필수 고어 500제 플래시카드 | [03_LITERATURE_VOCAB_LEARNING.md](file:///c:/Users/user/Desktop/aeguk/docs/03_LITERATURE_VOCAB_LEARNING.md) |
| **04** | **실시간 멀티플레이 퀴즈 대결** | 10초 스피드 대결, P2P/고스트 매칭 구조, 랭킹 및 티어 시스템 | [04_MULTIPLAYER_QUIZ.md](file:///c:/Users/user/Desktop/aeguk/docs/04_MULTIPLAYER_QUIZ.md) |
| **05** | **개인 학습 관리 & 대시보드** | 카테고리별(업무/개인/공부) 분류, 진행률 추적, 스트릭, 백업/복원 | [05_STUDY_MANAGEMENT_DASHBOARD.md](file:///c:/Users/user/Desktop/aeguk/docs/05_STUDY_MANAGEMENT_DASHBOARD.md) |
| **06** | **데이터 영속성 및 스토리지 스키마** | LocalStorage 데이터 모델링, 새로고침 시 무손실 보장 설계 | [06_DATA_SCHEMA_STORAGE.md](file:///c:/Users/user/Desktop/aeguk/docs/06_DATA_SCHEMA_STORAGE.md) |
| **07** | **시스템 아키텍처 및 구현 가이드** | Vanilla JS 디렉터리 구조, 옛한글 웹폰트, AI 연동 규격, 개발 로드맵 | [07_ARCHITECTURE_TECH_SPEC.md](file:///c:/Users/user/Desktop/aeguk/docs/07_ARCHITECTURE_TECH_SPEC.md) |

---

## 💡 기술 핵심 요약
- **No-Framework (Vanilla JS)**: 별도 빌드/설치 없이 `index.html` 더블 클릭만으로 브라우저에서 즉각 실행
- **무손실 영속화 (Zero Data Loss)**: 새로고침하거나 브라우저를 닫아도 `localStorage`를 통해 학습 기록 유지
- **모바일/PC 반응형**: 스마트폰 카메라 및 웹캠 지원
