/**
 * [App.js]
 * 메인 애플리케이션 진입점 및 1단계 온보딩 / 탭 네비게이션 제어
 */

document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  setupNavigation();
  checkOnboarding();
  updateHeaderUI();
  setupProfileModalEvents();
}

/* --- 탭 내비게이션 라우팅 --- */
function setupNavigation() {
  const navButtons = document.querySelectorAll('.nav-item');
  const panels = document.querySelectorAll('.tab-panel');

  navButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');

      // 탭 버튼 활성화 변경
      navButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      // 패널 활성화 변경
      panels.forEach(panel => {
        if (panel.id === `tab-${targetTab}`) {
          panel.classList.add('active');
        } else {
          panel.classList.remove('active');
        }
      });

      // 탭 전환 시 화면 상단으로 스크롤
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  });
}

/* --- 상단 헤더 프로필 & 스트릭 UI 갱신 --- */
function updateHeaderUI() {
  const profile = window.StorageApp.getProfile();
  const userNameEl = document.getElementById('header-user-name');
  const streakCountEl = document.getElementById('header-streak-count');

  if (profile) {
    if (userNameEl) userNameEl.textContent = profile.nickname || '학인';
    if (streakCountEl) streakCountEl.textContent = profile.streak || 1;
  } else {
    if (userNameEl) userNameEl.textContent = '학인 등록';
    if (streakCountEl) streakCountEl.textContent = '1';
  }
}

/* --- 온보딩 마법사 상태 및 제어 --- */
const onboardingState = {
  currentStep: 1,
  data: {
    grade: 'high_3',
    goal: 'sat_perfect',
    interests: ['gasa', 'grammar'],
    nickname: ''
  }
};

function checkOnboarding() {
  // 프로필이 없으면 온보딩 모달 오픈
  if (!window.StorageApp.hasProfile()) {
    openOnboardingModal();
  } else {
    closeOnboardingModal();
    renderWelcomeHome();
  }
}

function openOnboardingModal() {
  const modal = document.getElementById('onboarding-modal');
  if (modal) {
    modal.style.display = 'flex';
    onboardingState.currentStep = 1;
    renderOnboardingStep();
  }
}

function closeOnboardingModal() {
  const modal = document.getElementById('onboarding-modal');
  if (modal) modal.style.display = 'none';
}

function renderOnboardingStep() {
  const step = onboardingState.currentStep;
  
  // 스텝 인디케이터 갱신
  document.querySelectorAll('.step-dot').forEach((dot, idx) => {
    dot.classList.toggle('active', idx + 1 === step);
  });

  // 각 스텝 컨텐츠 노출 제어
  for (let i = 1; i <= 3; i++) {
    const el = document.getElementById(`onboarding-step-${i}`);
    if (el) el.style.display = (i === step) ? 'block' : 'none';
  }

  const prevBtn = document.getElementById('onboarding-btn-prev');
  const nextBtn = document.getElementById('onboarding-btn-next');

  if (step === 1) {
    prevBtn.style.display = 'none';
    nextBtn.textContent = '다음 (1/3)';
  } else if (step === 2) {
    prevBtn.style.display = 'block';
    nextBtn.textContent = '다음 (2/3)';
  } else if (step === 3) {
    prevBtn.style.display = 'block';
    nextBtn.textContent = '학습 시작하기';
  }
}

function setupProfileModalEvents() {
  // 1. 선택 카드 클릭 이벤트 (단일 선택: 학년, 목표)
  document.querySelectorAll('.selectable-single').forEach(card => {
    card.addEventListener('click', (e) => {
      const parent = card.closest('.option-grid');
      parent.querySelectorAll('.selectable-single').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');

      const group = card.getAttribute('data-group');
      const val = card.getAttribute('data-value');
      if (group === 'grade') onboardingState.data.grade = val;
      if (group === 'goal') onboardingState.data.goal = val;
    });
  });

  // 2. 다중 선택 카드 클릭 이벤트 (관심 분야)
  document.querySelectorAll('.selectable-multi').forEach(card => {
    card.addEventListener('click', () => {
      card.classList.toggle('selected');
      const val = card.getAttribute('data-value');
      const list = onboardingState.data.interests;
      const index = list.indexOf(val);
      if (index > -1) {
        list.splice(index, 1);
      } else {
        list.push(val);
      }
    });
  });

  // 3. 이전/다음 버튼
  const nextBtn = document.getElementById('onboarding-btn-next');
  const prevBtn = document.getElementById('onboarding-btn-prev');

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      if (onboardingState.currentStep < 3) {
        onboardingState.currentStep += 1;
        renderOnboardingStep();
      } else {
        // 완료 단계: 닉네임 검증 및 저장
        const nicknameInput = document.getElementById('input-nickname');
        const nickname = nicknameInput?.value.trim() || '율곡이이';
        onboardingState.data.nickname = nickname;

        // LocalStorage에 저장
        window.StorageApp.saveProfile(onboardingState.data);

        closeOnboardingModal();
        updateHeaderUI();
        renderWelcomeHome();
      }
    });
  }

  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      if (onboardingState.currentStep > 1) {
        onboardingState.currentStep -= 1;
        renderOnboardingStep();
      }
    });
  }

  // 상단 프로필 뱃지 클릭 시 정보 재설정 모달 열기
  const userBadge = document.getElementById('header-user-badge');
  if (userBadge) {
    userBadge.addEventListener('click', () => {
      const currentProfile = window.StorageApp.getProfile();
      if (currentProfile) {
        onboardingState.data = { ...currentProfile };
        const nickInput = document.getElementById('input-nickname');
        if (nickInput) nickInput.value = currentProfile.nickname || '';
      }
      openOnboardingModal();
    });
  }
}

// 온보딩 완료 후 메인 홈 맞춤 안내 문구 렌더링
function renderWelcomeHome() {
  const profile = window.StorageApp.getProfile();
  const welcomeBox = document.getElementById('welcome-banner');
  if (!welcomeBox || !profile) return;

  const goalMap = {
    'sat_perfect': '수능 국어 고전문학 만점',
    'gpa_top': '학교 내신 1등급 달성',
    'exam_pass': '시험 단기 합격',
    'hobby': '고전문헌 강독 & 인문학 교양'
  };

  welcomeBox.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <div>
        <h3 style="font-family:var(--font-serif); font-size:17px; margin-bottom:4px;">
          반갑습니다, <strong>${profile.nickname}</strong> 님
        </h3>
        <p style="font-size:12px; color:var(--text-secondary);">
          오늘의 목표: <span style="color:var(--color-pine); font-weight:600;">${goalMap[profile.goal] || '고전 완벽 마스터'}</span>
        </p>
      </div>
      <div style="text-align:right;">
        <span class="tag tag-study">연속 ${profile.streak}일차 공부 중 🔥</span>
      </div>
    </div>
  `;
}
