/**
 * [Storage.js]
 * LocalStorage 기반 데이터 영속화 중앙 관리 모듈
 * 새로고침 또는 브라우저 재시작 시에도 데이터가 보존되도록 보장합니다.
 */

const STORAGE_KEY = 'aeguk_classic_korean_data';

// 기본 데이터 템플릿
const DEFAULT_STATE = {
  profile: null, // 온보딩 완료 시 객체로 채워짐 { nickname, grade, goal, interests, streak: 1, lastLoginDate: ... }
  scans: [],    // 촬영 및 번역/해설 기록 [{ id, timestamp, category, imageUrl, originalText, translatedText, analysis, isFavorite }]
  vocabProgress: {
    masteredIds: [], // 암기 완료 단어 ID 목록
    starredIds: []   // 즐겨찾기 단어 ID 목록
  },
  quizStats: {
    totalPlayed: 0,
    wins: 0,
    highScore: 0,
    streak: 0,
    rankTitle: "훈장" // 훈장 -> 생원 -> 진사 -> 급제 -> 장원급제
  },
  settings: {
    soundEnabled: true,
    fontSize: "medium"
  }
};

class StorageManager {
  constructor() {
    this.state = this.loadState();
    this.updateStreak();
  }

  // 로컬 스토리지에서 전체 상태 로드
  loadState() {
    try {
      const serialized = localStorage.getItem(STORAGE_KEY);
      if (!serialized) {
        return JSON.parse(JSON.stringify(DEFAULT_STATE));
      }
      const parsed = JSON.parse(serialized);
      // 신규 필드 누락 방지 병합 (Deep merge fallback)
      return {
        ...DEFAULT_STATE,
        ...parsed,
        vocabProgress: { ...DEFAULT_STATE.vocabProgress, ...(parsed.vocabProgress || {}) },
        quizStats: { ...DEFAULT_STATE.quizStats, ...(parsed.quizStats || {}) },
        settings: { ...DEFAULT_STATE.settings, ...(parsed.settings || {}) }
      };
    } catch (err) {
      console.error("[Storage] 데이터 로드 실패, 기본값 복구:", err);
      return JSON.parse(JSON.stringify(DEFAULT_STATE));
    }
  }

  // 전체 상태 저장
  saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch (err) {
      console.error("[Storage] 데이터 저장 실패:", err);
    }
  }

  // --- 프로필 관리 ---
  getProfile() {
    return this.state.profile;
  }

  hasProfile() {
    return this.state.profile !== null && Boolean(this.state.profile.nickname);
  }

  saveProfile(profileData) {
    const today = new Date().toISOString().split('T')[0];
    this.state.profile = {
      ...this.state.profile,
      ...profileData,
      streak: this.state.profile?.streak || 1,
      lastLoginDate: today,
      updatedAt: new Date().toISOString()
    };
    this.saveState();
    return this.state.profile;
  }

  // 출석일(스트릭) 자동 갱신
  updateStreak() {
    if (!this.state.profile) return;
    const today = new Date().toISOString().split('T')[0];
    const lastDate = this.state.profile.lastLoginDate;

    if (!lastDate) {
      this.state.profile.lastLoginDate = today;
      this.state.profile.streak = 1;
      this.saveState();
      return;
    }

    if (lastDate !== today) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];

      if (lastDate === yesterdayStr) {
        this.state.profile.streak = (this.state.profile.streak || 0) + 1;
      } else {
        // 하루 이상 거름
        this.state.profile.streak = 1;
      }
      this.state.profile.lastLoginDate = today;
      this.saveState();
    }
  }

  // --- 스캔/번역 기록 관리 ---
  getScans(categoryFilter = 'all') {
    if (categoryFilter === 'all') return this.state.scans;
    return this.state.scans.filter(s => s.category === categoryFilter);
  }

  addScanRecord(record) {
    const newRecord = {
      id: 'scan_' + Date.now(),
      timestamp: new Date().toISOString(),
      isFavorite: false,
      ...record
    };
    this.state.scans.unshift(newRecord);
    this.saveState();
    return newRecord;
  }

  deleteScanRecord(id) {
    this.state.scans = this.state.scans.filter(s => s.id !== id);
    this.saveState();
  }

  // --- 어휘 진도 관리 ---
  getVocabProgress() {
    return this.state.vocabProgress;
  }

  toggleWordMastered(wordId) {
    const list = this.state.vocabProgress.masteredIds;
    const index = list.indexOf(wordId);
    if (index > -1) {
      list.splice(index, 1);
    } else {
      list.push(wordId);
    }
    this.saveState();
    return this.state.vocabProgress;
  }

  // --- 퀴즈 통계 관리 ---
  getQuizStats() {
    return this.state.quizStats;
  }

  updateQuizScore(score, isWin) {
    const stats = this.state.quizStats;
    stats.totalPlayed += 1;
    if (isWin) stats.wins += 1;
    if (score > stats.highScore) stats.highScore = score;

    // 티어 승급 로직
    if (stats.highScore >= 1200) stats.rankTitle = "장원급제";
    else if (stats.highScore >= 800) stats.rankTitle = "급제";
    else if (stats.highScore >= 500) stats.rankTitle = "진사";
    else if (stats.highScore >= 200) stats.rankTitle = "생원";
    else stats.rankTitle = "훈장";

    this.saveState();
    return stats;
  }

  // --- 데이터 백업 및 복원 ---
  exportJSON() {
    return JSON.stringify(this.state, null, 2);
  }

  importJSON(jsonString) {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed && typeof parsed === 'object') {
        this.state = { ...DEFAULT_STATE, ...parsed };
        this.saveState();
        return { success: true };
      }
      return { success: false, error: "유효하지 않은 데이터 포맷입니다." };
    } catch (e) {
      return { success: false, error: e.message };
    }
  }

  resetAll() {
    localStorage.removeItem(STORAGE_KEY);
    this.state = JSON.parse(JSON.stringify(DEFAULT_STATE));
  }
}

// 글로벌 싱글톤 인스턴스
window.StorageApp = new StorageManager();
